/**
 * @summary vite.config.js — Open Library Classic application.
 * @author AUTHOR_PENDING
 */
import vue from '@vitejs/plugin-vue'
import { defineConfig } from 'vite'
export default defineConfig({ plugins: [vue()] })
