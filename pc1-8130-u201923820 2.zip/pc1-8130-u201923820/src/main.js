/**
 * @summary main.js — Open Library Classic application.
 * @author AUTHOR_PENDING
 */
import { createApp } from 'vue';
import PrimeVue from 'primevue/config';
import Material from '@primeuix/themes/material';
import { definePreset } from '@primeuix/themes';
import { Card, Button, Toolbar, SelectButton } from 'primevue';
import App from './app.vue';
import i18n from './shared/presentation/i18n.js';
import './style.css';
import 'primeicons/primeicons.css';
const preset = definePreset(Material, { semantic: { primary: {50:'#eef6f3',100:'#d7e9e1',200:'#b3d2c4',300:'#8bb7a5',400:'#60927e',500:'#42745f',600:'#315d52',700:'#284c43',800:'#223e37',900:'#1b332e',950:'#0e1b17'} } });
const app = createApp(App);
app.use(PrimeVue, { ripple: true, theme: {preset, options: {darkModeSelector: false}} }).use(i18n);
app.component('pv-card', Card).component('pv-button', Button).component('pv-toolbar', Toolbar).component('pv-select-button', SelectButton);
app.mount('#app');
