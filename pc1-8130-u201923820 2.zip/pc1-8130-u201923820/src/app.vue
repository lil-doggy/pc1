<script setup>
/** @summary Coordinates the application layout and document language. @author AUTHOR_PENDING */
import { watch } from 'vue';
import { useI18n } from 'vue-i18n';
import AppHeader from './shared/presentation/components/app-header.vue';
import AppFooter from './shared/presentation/components/app-footer.vue';
import BookList from './library/presentation/components/book-list.vue';
const { t, locale } = useI18n();
watch(locale, value => { document.documentElement.lang = value; document.title = t('appTitle'); }, { immediate: true });
</script>

<template>
<a class="skip-link" href="#main">{{ t('skip') }}</a>
<app-header />
<main id="main" tabindex="-1"><book-list /></main>
<app-footer />
</template>
