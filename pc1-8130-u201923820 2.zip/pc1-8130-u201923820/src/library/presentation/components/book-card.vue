<script setup>
/** @summary Presents one classic book and accessible sharing controls. @author AUTHOR_PENDING */
import { computed, ref } from 'vue';
import { useI18n } from 'vue-i18n';
import { Book } from '../../domain/models/book.entity.js';
import { environment } from '../../../shared/infrastructure/environment.js';
import { ShareService } from '../../../shared/infrastructure/share.service.js';
const props = defineProps({book: {type: Book, required: true}});
const { t, te, locale } = useI18n();
const coverFailed = ref(false), shareStatus = ref(''), sharing = ref(false);
const title = computed(() => props.book.title || t('untitled'));
const cover = computed(() => props.book.coverId ? `${environment.coverUrl}${props.book.coverId}-${environment.coverSize}.jpg?default=false` : '');
const bookUrl = computed(() => new URL(props.book.id, environment.bookUrl).href);
const languages = computed(() => {
 const names = new Intl.DisplayNames([locale.value], {type: 'language'});
 return props.book.languages.map(code => { try { return te(`languageNames.${code}`) ? t(`languageNames.${code}`) : names.of(code); } catch { return code; } }).join(', ') || t('unknown');
});
/** @returns {Promise<void>} Shares the selected book and displays localized feedback. */
async function share() {
 sharing.value = true; shareStatus.value = '';
 try { shareStatus.value = await ShareService.share({title: title.value, text: [title.value, props.book.authors.join(', ')].filter(Boolean).join(' — '), url: bookUrl.value}); }
 catch { shareStatus.value = 'shareError'; }
 finally { sharing.value = false; }
}
</script>

<template>
<article :aria-labelledby="`title-${book.id.split('/').pop()}`" class="book-item">
 <pv-card class="book-card">
  <template #header><div class="cover-stage"><img v-if="cover && !coverFailed" :src="cover" :alt="t('coverAlt', {title})" loading="lazy" @error="coverFailed = true"><div v-else class="cover-placeholder"><i class="pi pi-book" aria-hidden="true"></i><span>{{ t('noCover') }}</span></div></div></template>
  <template #title><h2 :id="`title-${book.id.split('/').pop()}`">{{ title }}</h2></template>
  <template #subtitle><p class="publishers" tabindex="0">{{ book.publishers.join(' · ') || t('unknown') }}</p></template>
  <template #content><dl class="book-details"><div><dt>{{ t('author') }}</dt><dd>{{ book.authors.join(', ') || t('unknown') }}</dd></div><div><dt>{{ t('published') }}</dt><dd>{{ book.firstPublishYear ?? t('unknown') }}</dd></div><div><dt>{{ t('pages') }}</dt><dd>{{ book.pageCount?.toLocaleString(locale) ?? t('unknown') }}</dd></div></dl></template>
  <template #footer><div class="book-actions"><p class="book-languages"><strong>{{ t('language') }}</strong><span tabindex="0">{{ languages }}</span></p><pv-button :label="t('share')" icon="pi pi-share-alt" variant="text" :aria-label="t('shareBook', {title})" :loading="sharing" @click="share" /></div><p v-if="shareStatus" role="status" class="share-status">{{ t(shareStatus) }}</p><a v-if="shareStatus === 'shareError'" :href="bookUrl" class="manual-link">{{ t('bookLink') }}: {{ bookUrl }}</a></template>
 </pv-card>
</article>
</template>
