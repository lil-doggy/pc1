<script setup>
/** @summary Loads and displays the paginated classic collection. @author AUTHOR_PENDING */
import { computed, onMounted } from 'vue';
import { useI18n } from 'vue-i18n';
import BookCard from './book-card.vue';
import { useBookCatalog } from '../../application/book-catalog.store.js';
import { environment } from '../../../shared/infrastructure/environment.js';
const { t, locale } = useI18n();
const {books, total, page, loading, failed, load} = useBookCatalog();
const pages = computed(() => Math.max(1, Math.ceil(total.value / environment.pageSize)));
onMounted(() => load());
</script>

<template>
<section aria-labelledby="catalog-title" :aria-busy="loading">
 <div class="collection-heading"><p class="eyebrow">{{ t('eyebrow') }}</p><h1 id="catalog-title">{{ t('heading') }}</h1><p class="intro">{{ t('intro') }}</p></div>
 <div v-if="loading" role="status" class="state-panel"><i class="pi pi-spin pi-spinner" aria-hidden="true"></i><p>{{ t('loading') }}</p></div>
 <div v-else-if="failed" role="alert" class="state-panel"><i class="pi pi-cloud" aria-hidden="true"></i><p>{{ t('error') }}</p><pv-button :label="t('retry')" icon="pi pi-refresh" @click="load()" /></div>
 <p v-else-if="!books.length" role="status" class="state-panel">{{ t('empty') }}</p>
 <template v-else><p class="result-count">{{ t('results', {count: total.toLocaleString(locale)}) }}</p><div class="book-grid"><book-card v-for="book in books" :key="book.id" :book="book" /></div><nav class="pagination" :aria-label="t('pagination')"><pv-button :label="t('previous')" icon="pi pi-arrow-left" severity="secondary" :disabled="page === 1" @click="load(page - 1)" /><span aria-live="polite">{{ t('page', {page, total: pages}) }}</span><pv-button :label="t('next')" icon="pi pi-arrow-right" icon-pos="right" severity="secondary" :disabled="page >= pages" @click="load(page + 1)" /></nav></template>
</section>
</template>
