/**
 * @summary book-api.service.js — Open Library Classic application.
 * @author AUTHOR_PENDING
 */
import axios from 'axios';
import { environment } from '../../shared/infrastructure/environment.js';
import { BookSearchRequest } from './book-search.request.js';
import { BookSearchResponse } from './book-search.response.js';
/** @summary Retrieves classic books through Axios. @author AUTHOR_PENDING */
export class BookApiService {
 /** Initializes a single HTTP client. */
 constructor() { this.http = axios.create({ baseURL: environment.apiUrl, timeout: 25000 }); }
 /** @param {number} page Requested page. @param {AbortSignal} signal Cancellation signal. @returns {Promise<BookSearchResponse>} Search result. */
 async search(page, signal) {
  const response = await this.http.get(environment.searchPath, { params: new BookSearchRequest(environment, page), signal });
  return new BookSearchResponse(response.data);
 }
}
