/**
 * @summary book.assembler.js — Open Library Classic application.
 * @author AUTHOR_PENDING
 */
import { Book } from '../domain/models/book.entity.js';
/** @summary Maps provider resources into domain entities. @author AUTHOR_PENDING */
export class BookAssembler {
 /** @param {import('./book.resource.js').BookResource} resource API resource. @returns {Book} Normalized book. */
 static toEntity(resource) {
  const strings = value => Array.isArray(value) ? [...new Set(value.filter(item => typeof item === 'string' && item.trim()))] : [];
  return new Book({id: resource.key, title: resource.title || '', authors: strings(resource.author_name),
   publishers: strings(resource.publisher), firstPublishYear: Number.isFinite(resource.first_publish_year) ? resource.first_publish_year : null,
   pageCount: resource.number_of_pages_median > 0 ? resource.number_of_pages_median : null,
   languages: strings(resource.language), coverId: resource.cover_i > 0 ? resource.cover_i : null});
 }
}
