/**
 * @summary book.resource.js — Open Library Classic application.
 * @author AUTHOR_PENDING
 */
/**
 * @summary Open Library search resource contract; external names remain here only.
 * @author AUTHOR_PENDING
 * @typedef {object} BookResource
 * @property {string} key Work path.
 * @property {string} title Work title.
 * @property {string[]} [author_name] Authors.
 * @property {string[]} [publisher] Edition publishers.
 * @property {number} [first_publish_year] First publication year.
 * @property {number} [number_of_pages_median] Median pages across editions.
 * @property {string[]} [language] ISO language codes across editions.
 * @property {number} [cover_i] Cover identifier.
 */
export {};
