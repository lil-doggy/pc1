/**
 * @summary book-search.request.js — Open Library Classic application.
 * @author AUTHOR_PENDING
 */
/** @summary Encapsulates the search request parameters. @author AUTHOR_PENDING */
export class BookSearchRequest {
 /** @param {object} config Search configuration. @param {number} page One-based page. */
 constructor(config, page = 1) {
  this.subject = config.subject; this.fields = config.fields;
  this.limit = config.pageSize; this.page = page;
 }
}
