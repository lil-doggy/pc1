/**
 * @summary book-search.response.js — Open Library Classic application.
 * @author AUTHOR_PENDING
 */
import { BookAssembler } from './book.assembler.js';
/** @summary Validates and assembles a paginated search response. @author AUTHOR_PENDING */
export class BookSearchResponse {
 /** @param {object} data JSON response body. @throws {TypeError} On invalid response. */
 constructor(data) {
  if (!Array.isArray(data?.docs)) throw new TypeError('Invalid book search response');
  this.books = data.docs.filter(item => typeof item?.key === 'string').map(BookAssembler.toEntity);
  this.total = Number.isFinite(data.numFound) ? data.numFound : this.books.length;
 }
}
