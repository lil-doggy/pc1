/**
 * @summary book-catalog.store.js — Open Library Classic application.
 * @author AUTHOR_PENDING
 */
import { ref, onScopeDispose } from 'vue';
import { BookApiService } from '../infrastructure/book-api.service.js';
/** @summary Manages catalog loading, pagination and cancellation. @author AUTHOR_PENDING
 * @returns {object} Reactive catalog state and actions.
 */
export function useBookCatalog() {
 const books = ref([]), total = ref(0), page = ref(1), loading = ref(false), failed = ref(false);
 const service = new BookApiService(); let controller;
 /** @param {number} nextPage One-based page to load. @returns {Promise<void>} Completion. */
 async function load(nextPage = page.value) {
  controller?.abort(); controller = new AbortController(); const current = controller;
  loading.value = true; failed.value = false; books.value = []; page.value = nextPage;
  try { const result = await service.search(nextPage, current.signal);
   if (!current.signal.aborted) { books.value = result.books; total.value = result.total; }
  } catch { if (!current.signal.aborted) failed.value = true;
  } finally { if (!current.signal.aborted) loading.value = false; }
 }
 onScopeDispose(() => controller?.abort());
 return { books, total, page, loading, failed, load };
}
