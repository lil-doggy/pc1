/**
 * @summary book.entity.js — Open Library Classic application.
 * @author AUTHOR_PENDING
 */
/** @summary A literary work with provider-independent property names. @author AUTHOR_PENDING */
export class Book {
 /** @param {object} attributes Normalized book attributes. */
 constructor({id, title, authors = [], publishers = [], firstPublishYear = null, pageCount = null, languages = [], coverId = null}) {
  Object.assign(this, {id, title, authors, publishers, firstPublishYear, pageCount, languages, coverId});
 }
}
