/**
 * @summary environment.js — Open Library Classic application.
 * @author AUTHOR_PENDING
 */
const env = import.meta.env;
export const environment = Object.freeze({
 apiUrl: env.VITE_OPEN_LIBRARY_API_URL, searchPath: env.VITE_BOOK_SEARCH_PATH,
 subject: env.VITE_BOOK_SUBJECT, fields: env.VITE_BOOK_FIELDS,
 pageSize: Number(env.VITE_BOOK_PAGE_SIZE), bookUrl: env.VITE_BOOK_URL,
 coverUrl: env.VITE_COVER_URL, coverSize: env.VITE_COVER_SIZE,
 logoUrl: env.VITE_LOGO_API_URL, logoDomain: env.VITE_LOGO_DOMAIN,
 logoToken: env.VITE_LOGO_PUBLIC_TOKEN, logoAttribution: env.VITE_LOGO_ATTRIBUTION_URL,
 author: env.VITE_AUTHOR_NAME, studentCode: env.VITE_STUDENT_CODE,
});
