/**
 * @summary share.service.js — Open Library Classic application.
 * @author AUTHOR_PENDING
 */
/** @summary Uses native sharing with clipboard fallback. @author AUTHOR_PENDING */
export class ShareService {
 /** @param {{title: string, text: string, url: string}} data Share payload. @param {Navigator} browser Browser adapter. @returns {Promise<string>} Result translation key. */
 static async share(data, browser = navigator) {
  if (typeof browser.share === 'function') {
   try { await browser.share(data); return 'shared'; }
   catch (error) { if (error.name === 'AbortError') return ''; }
  }
  if (!browser.clipboard?.writeText) throw new Error('Clipboard unavailable');
  await browser.clipboard.writeText(data.url); return 'copied';
 }
}
