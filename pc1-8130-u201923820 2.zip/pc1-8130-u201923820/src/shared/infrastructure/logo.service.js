/**
 * @summary logo.service.js — Open Library Classic application.
 * @author AUTHOR_PENDING
 */
import { environment } from './environment.js';
/** @summary Builds Logo.dev URLs using a browser-safe publishable token. @author AUTHOR_PENDING */
export class LogoService {
 /** @returns {string} Logo URL or empty string when no token is configured. */
 static getUrl() {
  if (!environment.logoToken) return '';
  const url = new URL(encodeURIComponent(environment.logoDomain), environment.logoUrl);
  url.searchParams.set('token', environment.logoToken); url.searchParams.set('size', '80');
  return url.href;
 }
}
