<script setup>
/** @summary Displays the centered brand and language selector. @author AUTHOR_PENDING */
import { ref } from 'vue';
import { useI18n } from 'vue-i18n';
import { LogoService } from '../../infrastructure/logo.service.js';
const { t, locale } = useI18n();
const logo = LogoService.getUrl(); const logoFailed = ref(false);
const languages = [{ label: 'EN', value: 'en' }, { label: 'ES', value: 'es' }];
</script>

<template>
<header class="site-header">
 <pv-toolbar :aria-label="t('toolbar')" class="site-toolbar">
  <template #start><pv-select-button v-model="locale" :options="languages" option-label="label" option-value="value" :allow-empty="false" :aria-label="t('chooseLanguage')" /></template>
  <template #center><div class="brand"><img v-if="logo && !logoFailed" :src="logo" :alt="t('logoAlt')" width="40" height="40" @error="logoFailed = true"><i v-else class="pi pi-book" aria-hidden="true"></i><span>{{ t('appTitle') }}</span></div></template>
  <template #end><span class="header-ornament" aria-hidden="true">OL / 2026</span></template>
 </pv-toolbar>
</header>
</template>
