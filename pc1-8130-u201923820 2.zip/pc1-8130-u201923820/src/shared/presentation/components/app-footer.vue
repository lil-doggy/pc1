<script setup>
/** @summary Displays copyright, author and logo attribution. @author AUTHOR_PENDING */
import { useI18n } from 'vue-i18n';
import { environment } from '../../infrastructure/environment.js';
const { t } = useI18n();
</script>

<template>
<footer class="site-footer"><p>{{ t('copyright') }}</p><p>{{ t('developed', {code: environment.studentCode, name: environment.author}) }}</p><a v-if="environment.logoToken" :href="environment.logoAttribution" target="_blank" rel="noopener noreferrer">{{ t('logoCredit') }}</a></footer>
</template>
