# Open Library Classic

A Vue 3.5 application for discovering classic books from the public Open Library catalog. Built with Vite, JavaScript, Composition API, PrimeVue's Material theme, Axios and Vue I18n.

## Author

AUTHOR_PENDING · Student code: u201923820 · NRC: 8130.

Project and submission name: `pc18130u201923820`. The current WebStorm workspace is named `pc1-8130-u201923820`; the ZIP contains the required `pc18130u201923820` root directory. To rename the workspace itself, close it in WebStorm, rename the folder and reopen it. No nested application is necessary.

## Run in WebStorm

Use Node.js **22.12 or newer** (Node 24 LTS recommended) and npm **10 or newer**. Open the project root containing `package.json` in WebStorm and select its Node interpreter. Run all commands from that root:

```sh
npm ci
npm run dev
```

Open the local URL printed by Vite. For a copy without a lockfile, use `npm install` instead of `npm ci`.

```sh
npm test
npm run build
npm run preview
```

The tests use Node's built-in test runner. Build output goes to `dist`. Preview serves the production build locally; it is not a production server.

## Features

- Centered brand and Logo.dev integration, with EN/ES language selection on the left.
- English by default; all fixed UI text, accessible labels and feedback translate into Spanish.
- Three book cards per row on desktop, two on tablets and one on phones.
- Covers, titles, edition publishers, authors, first publication year, median page count and all available work languages.
- Native browser sharing with clipboard fallback, cancellation handling and a manual link when both capabilities fail.
- Twelve works per page, catalog pagination, loading, empty, error and retry states.
- Semantic landmarks, labeled controls, keyboard focus, skip navigation and live feedback.
- Copyright and student attribution.

Open Library aggregates editions into works. Publisher and language arrays may contain many values; scrollable areas preserve every value without truncating the underlying data. Publication year and median page count are the values supplied by the API, not dates/pages inferred from a particular edition. Book titles, personal names and publisher names retain their original spelling.

## Environment configuration

`.env.development` and `.env.production` independently define the API URLs, search path, subject, selected response fields, page size, cover size, Logo.dev domain and attribution, and author details. Vite loads development variables for `npm run dev`, and production variables for `npm run build`. Restart development or rebuild after changing them.

| Variable | Purpose |
| --- | --- |
| `VITE_OPEN_LIBRARY_API_URL` | Open Library API origin |
| `VITE_BOOK_SEARCH_PATH` | Search endpoint path |
| `VITE_BOOK_SUBJECT` | Catalog subject (`classics`) |
| `VITE_BOOK_FIELDS` | Response fields, including `publisher` |
| `VITE_BOOK_PAGE_SIZE` | Positive page size (12 by default) |
| `VITE_BOOK_URL` | Public work URL origin for sharing |
| `VITE_COVER_URL`, `VITE_COVER_SIZE` | Cover service and image size |
| `VITE_LOGO_API_URL`, `VITE_LOGO_DOMAIN` | Logo.dev service and requested domain |
| `VITE_LOGO_PUBLIC_TOKEN` | Logo.dev publishable browser token |
| `VITE_LOGO_ATTRIBUTION_URL` | Logo.dev attribution link |
| `VITE_AUTHOR_NAME`, `VITE_STUDENT_CODE` | Footer attribution |

Open Library requires no API key for this application. To enable the requested logo, create a Logo.dev account, obtain its **publishable** token and configure it in `.env.development.local` and `.env.production.local`:

```dotenv
VITE_LOGO_PUBLIC_TOKEN=YOUR_PUBLISHABLE_TOKEN
```

These local files are ignored and excluded from the ZIP. Restrict the token to your deployment domains in Logo.dev where applicable. **Every `VITE_*` value is visible to the browser. Never add a private or secret API key.** The application displays a book icon if the token is absent or the remote logo cannot load. Logo.dev attribution appears when a token is configured.

## Dependencies and installation from scratch

For this existing project, `npm ci` installs the declared dependencies from the supplied lockfile. The following explicit commands are only for recreating or adding the dependencies, not an additional setup step. Versions exactly match `package.json`.

Runtime dependencies:

```sh
npm install vue@~3.5.42 primevue@^4.3.3 @primeuix/themes@^1.2.3 primeicons@^7.0.0 axios@^1.8.4 vue-i18n@^11.1.3
```

Development dependencies:

```sh
npm install -D @vitejs/plugin-vue@^6.0.8 vite@^8.3.0
```

`@primeuix/themes/material` supplies PrimeVue's Material preset. No router or external state management library is needed for this single-view application.

## Architecture

```text
src/
  library/
    domain/models/                  Book entity with camelCase attributes
    infrastructure/
      resources/                    External snake_case resource contract
      requests/                     Search request object
      responses/                    Validated search response
      assemblers/                   Resource-to-entity mapping
      services/                     Axios API service
    application/                    Reactive catalog store and orchestration
    presentation/components/        Book list and card
  shared/
    infrastructure/config/          Environment adapter
    infrastructure/services/        Logo and browser share services
    presentation/components/        Header and footer
    presentation/locales/           English and Spanish messages
    presentation/i18n.js            Internationalization setup
```

The application uses Request/Response, Resource and Assembler patterns. The domain has no Vue, HTTP or provider dependency. The Composition API store manages requests, pagination and cancellation; components render entities and handle UI interaction. Physical source names use kebab-case, model/service files use responsibility suffixes, and PrimeVue components use the `pv-` prefix.

## Verification checklist

- [x] Vue 3.5, Vite, Composition API and Material PrimeVue preset.
- [x] Live classics endpoint with `publisher` explicitly requested.
- [x] Three-column desktop cards and responsive layout.
- [x] Covers, publishers, authors, publication years, pages and all languages.
- [x] EN/ES messages and document language updates.
- [x] Native share and clipboard fallback with error handling.
- [x] Environment-specific configuration and no private keys.
- [x] Domain-driven layered organization and documented source.
- [x] Unit tests for response mapping and sharing behavior.
- [ ] Configure a Logo.dev publishable token to verify the remote brand logo.
- [ ] Complete and confirm author details before submission.

## Delivery

The ZIP contains one `pc18130u201923820/` project directory with source, tests, environment defaults, package manifest, lockfile and this README. It excludes `node_modules`, `dist`, IDE state, local environment overrides and temporary files. Extract it, open that directory in WebStorm and run `npm ci`.
